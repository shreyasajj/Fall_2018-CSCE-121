#include <iostream>
#include<cmath>
#include <iomanip>
using namespace std;
int main(){
    double a;
    double b;
    double c;
    while(true) {
        cout<<"Input value of a"<<endl;
        cin >> a;
        if (cin.fail()) {
            cin.clear();
            cin.ignore(10000, '\n');
            cout << "Invalid Input" << endl;
        }else
            break;

    }
    while(true) {
        cout<<"Input value of b"<<endl;
        cin >> b;
        if (cin.fail()) {
            cin.clear();
            cin.ignore(10000, '\n');
            cout << "Invalid Input" << endl;
        }else
            break;

    }
    while(true) {
        cout<<"Input value of c"<<endl;
        cin >> c;
        if (cin.fail()) {
            cin.clear();
            cin.ignore(10000, '\n');
            cout << "Invalid Input" << endl;
        }else
            break;

    }
    double discriminant = pow(b,2)-(4*a*c);
    if(discriminant<0){
        cout<<"No Real Solution"<<endl;
    }else if(discriminant==0){
        double root=(-b)/(2*a);
        cout<<"The solution is "<<fixed<<setprecision(4)<<root;

    }else{
        double root1 = ((-b)+sqrt(discriminant))/(2*a);
        double root2 = ((-b)-sqrt(discriminant))/(2*a);
        cout<<"The solution is "<<fixed<<setprecision(4)<<root1<<" and "<<fixed<<setprecision(4)<<root2;
    }

}
