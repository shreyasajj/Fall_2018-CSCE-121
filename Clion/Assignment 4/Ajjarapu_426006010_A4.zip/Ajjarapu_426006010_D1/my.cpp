//
// Created by shrey on 10/3/2018.
//

#include "my.h"
//#include "std_lib_facilities.h"

//int foo;


void print_foo() {
    cout<<"The value of foo is "<<foo<<endl;
}
void print(int i){
    cout<< "The value of i is "<<i<<endl;
}