//
// Created by shrey on 10/3/2018.
//
#include <iostream>
using namespace std;
extern int foo;


void print_foo();
void print(int);


