#include "my.h"
#include <iostream>

int foo;

int main() {
    foo=7;

    print(99);
    print_foo();

}