Name: Shreyas, Ajjarapu UIN:426006010 Section Number:510 User Name:shreyasajj Email:Shreyasajj@tamu.edu

I certify that I have listed all the sources that I used to develop the solutions/codes to
the submitted work.
On my honor as an Aggie, I have neither given nor received any unauthorized
help on this academic work.

Problems:
Compiling
Failed to put a ) on a function call
Failed to put a ending }
Failed to put an intial value for val
Forgot to put c in class
Forgot to put put the ending "
Runtime:
Failed to put - for subtraction
Failed to put the correct case brackets for * and need break
Failed to put number 8 as a case that would be a number.

The Bull and Cows work on the premis of finding stuff in arrays. It splits up the input and check for incorrect values. Finally it checks if the values are in the intial version.
If they are, it check for if its in the right place. If it is bull otherwise cow. When 5 bulls are reach it finishes the game and show the count.