First Name:Shreyas 
Last Name:Ajjarapu 
UIN:426006010 
Section:510 
Username:Shreyasajj 
Email:shreyasajj@tamu.edu

I certify that I have listed all the sources that I used to develop the solutions/code to
the submitted work.
On my honor as an Aggie, I have neither given nor received any unauthorized
help on this academic work.
Your Name:Shreyas Ajjarapu    Date:10/29/2018

The lobby works off classes and enums. It combines thoes idea together as well as what you told me to do.
The Ex were completed based on assesment of vectors and redifinition of idea. It sorts with bubble sort and uses classes to keep it nice and tidy.


External sources:
http://www.cplusplus.com/
