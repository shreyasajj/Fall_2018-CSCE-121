First Name:Shreyas 
Last Name:Ajjarapu 
UIN:426006010 
Section:510 
Username:Shreyasajj 
Email:shreyasajj@tamu.edu

I certify that I have listed all the sources that I used to develop the solutions/code to
the submitted work.
On my honor as an Aggie, I have neither given nor received any unauthorized
help on this academic work.
Your Name:Shreyas Ajjarapu    Date:10/29/2018

The Link list is how we desribed in class. We changed and replaced each value by successor.
EX14 i couldnt get to work for the erase.

External sources:
http://www.cplusplus.com/
