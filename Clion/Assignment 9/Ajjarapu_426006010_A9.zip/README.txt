Shreyas, Ajjarapu, 426006010, 510, shreyasajj, shreyasajj@tamu.edu
I certify that I have listed all the sources that I used to develop the solutions
and code to the submitted work.
On my honor as an Aggie, I have neither given nor received any
unauthorized help on this academic work
Your Name: Shreyas Ajjarapu Date: 12/2/2018
No problems
The program takes the input of a maze and utilizes it create a 2D vector of the tiles that exist. 
Then it places the People at the start positions. Finally it ask for an input validates the input and moves. 
Finally it finishes when someone reaches the end.
I didnt use any exception but I used the debugger to validate the input and see the progress of the values.
